# Product/Platform - Task

This is the repository template for creating new examples. Describe the solved task here.

Put a screenshot that illustrates the result here.

Then, add implementation details (steps, code snippets, and other technical information in a free form), or add a link to an existing document with implementation details. 

## Files to Look At

- link.cs (VB: link.vb)
- link.js
- ...

## Documentation

- link
- link
- ...

## More Examples

- link
- link
- ...
